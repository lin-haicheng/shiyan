# MkDocs构建静态网站模板

<https://github.com/Yang-Xijie/mkdocs-site>

- 使用教程 [mkdocs-site](https://yang-xijie.github.io/BLOG/Markdown/mkdocs-site/)

---

- 生成 [MkDocs](https://www.mkdocs.org) 
- 主题 [Material](https://github.com/squidfunk/mkdocs-material)
- 发布 [GitHub Pages](https://yang-xijie.github.io/BLOG/Markdown/github-pages/) 
